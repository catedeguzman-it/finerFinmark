import { PageClient } from "./page-client";

export const metadata = {
  title: "Dashboard - Stack Template",
};

export default function Dashboard() {
  return <PageClient />;
}
