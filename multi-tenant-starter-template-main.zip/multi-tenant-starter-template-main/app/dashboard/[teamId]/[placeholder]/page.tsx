export default function Page() {
  return (
    <div>
      <h1>Example Page</h1>
    </div>
  )
}